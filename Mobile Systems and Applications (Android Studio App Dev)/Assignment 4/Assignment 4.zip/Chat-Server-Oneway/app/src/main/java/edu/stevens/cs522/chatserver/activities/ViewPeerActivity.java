package edu.stevens.cs522.chatserver.activities;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;

import edu.stevens.cs522.chatserver.R;
import edu.stevens.cs522.chatserver.contracts.MessageContract;
import edu.stevens.cs522.chatserver.contracts.PeerContract;
import edu.stevens.cs522.chatserver.entities.Peer;

/**
 * Created by dduggan.
 */

public class ViewPeerActivity extends FragmentActivity implements LoaderManager.LoaderCallbacks<Cursor>{

    public static final String PEER_KEY = "peer";
    private SimpleCursorAdapter messageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peer);

        Peer peer = getIntent().getParcelableExtra(PEER_KEY);
        if (peer == null) {
            throw new IllegalArgumentException("Expected peer as intent extra");
        }

        // TODO init the UI
        String[] from = {MessageContract.MESSAGE_TEXT};
        int[] to = {android.R.id.text1};
        messageAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, null, from, to, 0);


        TextView userName = this.findViewById(R.id.view_user_name);
        TextView timestamp = this.findViewById(R.id.view_timestamp);
        TextView address = this.findViewById(R.id.view_address);
        ListView messages = this.findViewById(R.id.view_messages);

        userName.setText(peer.name);
        timestamp.setText(peer.timestamp.toString());
        address.setText(peer.address.toString());
        messages.setAdapter(messageAdapter);

        messageAdapter.notifyDataSetChanged();

        Bundle bundle = new Bundle();
        bundle.putLong(PEER_KEY,peer.id);

        LoaderManager.getInstance(this).initLoader(1, bundle, this);

    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        // TODO use a CursorLoader to initiate a query on the database
        // Filter messages with the sender id
        String selection = (MessageContract.SENDER_ID + "=?");
        String[] selectionArgs = new String[] {String.valueOf(args.getLong(PEER_KEY))};
        return new CursorLoader(this, MessageContract.CONTENT_URI, null, selection, selectionArgs, null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        // TODO populate the UI with the result of querying the provider
        this.messageAdapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // TODO reset the UI when the cursor is empty
        this.messageAdapter.swapCursor(null);
    }

}
