package edu.stevens.cs522.chatserver.entities;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

/**
 * Created by dduggan.
 */

public class Message implements Parcelable {

    public long id;

    public String chatRoom;

    public String messageText;

    public Date timestamp;

    public Double latitude;

    public Double longitude;

    public String sender;

    public long senderId;

    @Override
    public String toString() {
        return sender + ":" + messageText;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        // TODO
        dest.writeLong(this.id);
        dest.writeString(this.chatRoom);
        dest.writeString(this.messageText);
        dest.writeSerializable(this.timestamp);
        dest.writeDouble(this.longitude);
        dest.writeDouble(this.latitude);
        dest.writeString(this.sender);
        dest.writeLong(this.senderId);
    }

    public Message() {
    }

    public Message(Parcel in) {
        // TODO
        id = in.readLong();
        chatRoom = in.readString();
        messageText = in.readString();
        timestamp = (Date) in.readSerializable();
        longitude = in.readDouble();
        latitude = in.readDouble();
        sender = in.readString();
        senderId = in.readLong();
    }

    public static final Creator<Message> CREATOR = new Creator<Message>() {

        @Override
        public Message createFromParcel(Parcel source) {
            // TODO
            return new Message(source);
        }

        @Override
        public Message[] newArray(int size) {
            // TODO
            return new Message[size];
        }

    };

}

