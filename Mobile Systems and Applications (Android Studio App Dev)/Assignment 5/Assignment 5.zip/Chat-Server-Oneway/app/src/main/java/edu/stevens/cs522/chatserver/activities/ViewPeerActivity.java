package edu.stevens.cs522.chatserver.activities;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.stevens.cs522.chatserver.R;
import edu.stevens.cs522.chatserver.databases.ChatDatabase;
import edu.stevens.cs522.chatserver.entities.Message;
import edu.stevens.cs522.chatserver.entities.Peer;
import edu.stevens.cs522.chatserver.ui.MessageAdapter;
import edu.stevens.cs522.chatserver.ui.TextAdapter;

/**
 * Created by dduggan.
 */

public class ViewPeerActivity extends FragmentActivity {

    public static final String PEER_KEY = "peer";

    private ChatDatabase chatDatabase;

    private LiveData<List<Message>> messages;

    private TextAdapter<Message> messageAdapter;

    private RecyclerView messagesList;

    private Peer peer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peer);

        peer = getIntent().getParcelableExtra(PEER_KEY);
        if (peer == null) {
            throw new IllegalArgumentException("Expected peer id as intent extra");
        }

        // TODO init the UI
        messagesList = findViewById(R.id.view_messages);

        messageAdapter = new TextAdapter<Message>(messagesList);

        messagesList.setLayoutManager(new LinearLayoutManager(this));

        chatDatabase = ChatDatabase.getInstance(getApplicationContext());

        messagesList.setAdapter(messageAdapter);
        messages = chatDatabase.messageDao().fetchMessagesFromPeer(peer.id);
        final Observer<List<Message>> observer = new Observer<List<Message>>() {
            @Override
            public void onChanged(List<Message> messages) {
                messageAdapter.setDataset(messages);
                messageAdapter.notifyDataSetChanged();
            }
        };
        messages.observe(this, observer);


        TextView userName = this.findViewById(R.id.view_user_name);
        TextView timestamp = this.findViewById(R.id.view_timestamp);
        TextView address = this.findViewById(R.id.view_address);

        userName.setText(peer.name);
        timestamp.setText(peer.timestamp.toString());
        address.setText(peer.address.toString());

    }

}
