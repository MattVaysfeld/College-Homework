package edu.stevens.cs522.chat.databases;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.List;

import edu.stevens.cs522.chat.entities.Peer;

/*
 * TODO add annotations (NB insert should ignore conflicts, for upsert)
 *
 * We will continue to allow insertion to be done on main thread for noew.
 */
@Dao
public abstract class PeerDAO {

    @Query("SELECT * FROM peer")
    public abstract LiveData<List<Peer>> fetchAllPeers();

    @Query("SELECT * FROM peer WHERE id = :peerId LIMIT 1")
    public abstract ListenableFuture<Peer> fetchPeer(long peerId);

    @Query("SELECT * FROM peer WHERE name LIKE :name LIMIT 1")
    protected abstract long getPeerId(String name);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    public abstract long insert(Peer peer);

    @Update
    protected abstract void update(Peer peer);

    @Transaction
    /**
     * TODO This operation must be transactional, to avoid race condition
     * between getPeerId and insert/update.
     */
    public long upsert(Peer peer) {
        // TODO
        peer.id = getPeerId(peer.name);
        if (peer.id == 0) {
            peer.id = insert(peer);
        } else {
            update(peer);
        }
        return peer.id;
    }
}
