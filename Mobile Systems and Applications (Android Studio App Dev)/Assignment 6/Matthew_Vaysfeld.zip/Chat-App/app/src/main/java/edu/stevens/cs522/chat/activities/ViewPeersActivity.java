package edu.stevens.cs522.chat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.stevens.cs522.chat.R;
import edu.stevens.cs522.chat.databases.ChatDatabase;
import edu.stevens.cs522.chat.entities.Peer;
import edu.stevens.cs522.chat.ui.TextAdapter;


public class ViewPeersActivity extends FragmentActivity implements TextAdapter.OnItemClickListener {

    /*
     * TODO See ChatServer for example of what to do, query peers database instead of messages database.
     */

    private ChatDatabase chatDatabase;

    private LiveData<List<Peer>> peers;

    private TextAdapter<Peer> peerAdapter;

    private RecyclerView peersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peers);

        peersList = findViewById(R.id.peer_list);

        peerAdapter = new TextAdapter<>(peersList, this);

        // TODO initialize peerAdapter with result of asynchronous DB query
        peersList.setLayoutManager(new LinearLayoutManager(this));
        chatDatabase = ChatDatabase.getInstance(getApplicationContext());

        peersList.setAdapter(peerAdapter);
        peers = chatDatabase.peerDao().fetchAllPeers();
        final Observer<List<Peer>> observer = new Observer<List<Peer>>() {
            @Override
            public void onChanged(List<Peer> peers) {
                peerAdapter.setDataset(peers);
                peerAdapter.notifyDataSetChanged();
            }
        };
        peers.observe(this, observer);
        peersList.setOnClickListener(peerAdapter);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (chatDatabase.isOpen()) {
            chatDatabase.close();
            chatDatabase = null;
        }
    }

    /*
     * Callback interface defined in TextAdapter, for responding to clicks on rows.
     */
    @Override
    public void onItemClick(RecyclerView parent, View view, int position) {
        /*
         * Clicking on a peer brings up details
         */
        Peer peer = peers.getValue().get(position);

        Intent intent = new Intent(this, ViewPeerActivity.class);
        intent.putExtra(ViewPeerActivity.PEER_KEY, peer);
        startActivity(intent);

    }
}
