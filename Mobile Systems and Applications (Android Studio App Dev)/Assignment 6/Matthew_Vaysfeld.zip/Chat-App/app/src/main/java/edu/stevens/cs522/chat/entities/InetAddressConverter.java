package edu.stevens.cs522.chat.entities;

import androidx.room.TypeConverter;

import java.net.InetAddress;
import java.util.Date;

import edu.stevens.cs522.base.InetAddressUtils;

// TODO complete this class (use InetAddressUtils)
public class InetAddressConverter {
    @TypeConverter
    public static InetAddress fromAddress(String value) {
        return value == null ? null : InetAddressUtils.fromString(value.substring(1));
    }

    @TypeConverter
    public static String inetAddressToAddress(InetAddress Inetaddress) {
        return Inetaddress == null ? null : Inetaddress.toString();
    }
}
