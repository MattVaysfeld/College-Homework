package edu.stevens.cs522.chat.sync;

import android.content.Context;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class SyncManager {

    // WorkManager requires minimum period of 15 minutes between periodic requests
    public static final int INTERVAL = 15;


    private static final String SYNC_TAG = "chat-sync";


    public static void ScheduleSync(Context context) {
        // Use constraints to require e.g. WIFI connection before transferring data
        Constraints constraints = new Constraints.Builder().build();

        PeriodicWorkRequest syncRequest =
                new PeriodicWorkRequest.Builder(SyncWorker.class, INTERVAL, TimeUnit.MINUTES)
                                       .setConstraints(constraints)
                                       .setBackoffCriteria(
                                            BackoffPolicy.LINEAR,
                                            OneTimeWorkRequest.MIN_BACKOFF_MILLIS,
                                            TimeUnit.MILLISECONDS)
                                       .build();

        WorkManager.getInstance(context)
                   .enqueueUniquePeriodicWork(SYNC_TAG, ExistingPeriodicWorkPolicy.KEEP, syncRequest);
    }
}
