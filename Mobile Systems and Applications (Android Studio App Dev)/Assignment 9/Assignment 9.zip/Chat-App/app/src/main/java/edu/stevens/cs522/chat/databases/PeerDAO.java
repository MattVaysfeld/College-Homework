package edu.stevens.cs522.chat.databases;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.List;

import edu.stevens.cs522.chat.entities.Peer;

/*
 * TODO add annotations
 */
@Dao
public abstract class PeerDAO {

    // TODO
    @Query("SELECT * FROM peer")
    public abstract LiveData<List<Peer>> fetchAllPeers();

    // TODO
    @Query("SELECT * FROM peer WHERE id = :peerId LIMIT 1")
    public abstract ListenableFuture<Peer> fetchPeer(long peerId);

    // TODO
    @Query("SELECT * FROM peer WHERE name LIKE :name LIMIT 1")
    protected abstract long getPeerId(String name);

    // TODO
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    protected abstract void insert(Peer peer);

    // TODO
    @Update
    protected abstract void update(Peer peer);

    @Transaction
    /**
     * This operation must be transactional, to avoid race condition
     * between conflict on insert and update.
     */
    public void upsert(Peer peer) {
        // TODO
        long id = getPeerId(peer.name);
        if (id == 0) {
            insert(peer);
        } else {
            update(peer);
        }
    }
}
