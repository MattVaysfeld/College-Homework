package edu.stevens.cs522.chatserver.activities;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import edu.stevens.cs522.chatserver.R;
import edu.stevens.cs522.chatserver.contracts.MessageContract;
import edu.stevens.cs522.chatserver.contracts.PeerContract;
import edu.stevens.cs522.chatserver.databases.ChatDbAdapter;
import edu.stevens.cs522.chatserver.entities.Peer;

/**
 * Created by dduggan.
 */

public class ViewPeerActivity extends Activity {

    public static final String PEER_KEY = "peer";

    private ChatDbAdapter chatDbAdapter;

    private Cursor cursor;

    private ListView messages;

    private SimpleCursorAdapter messageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peer);

        Peer peer = getIntent().getParcelableExtra(PEER_KEY);
        if (peer == null) {
            throw new IllegalArgumentException("Expected peer id as intent extra");
        }

        // TODO init the UI

        chatDbAdapter = new ChatDbAdapter(this);
        chatDbAdapter.open();
        cursor = chatDbAdapter.fetchMessagesFromPeer(peer);
        startManagingCursor(cursor);

        String[] from = {MessageContract.MESSAGE_TEXT};
        int[] to = {android.R.id.text1};
        messageAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, cursor, from, to);


        TextView userName = this.findViewById(R.id.view_user_name);
        TextView timestamp = this.findViewById(R.id.view_timestamp);
        TextView address = this.findViewById(R.id.view_address);
        ListView messages = this.findViewById(R.id.view_messages);

        userName.setText(peer.name);
        timestamp.setText(peer.timestamp.toString());
        address.setText(peer.address.toString());
        messages.setAdapter(messageAdapter);

    }

}
