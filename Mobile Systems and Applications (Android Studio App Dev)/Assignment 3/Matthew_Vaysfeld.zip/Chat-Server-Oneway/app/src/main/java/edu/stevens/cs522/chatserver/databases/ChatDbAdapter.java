package edu.stevens.cs522.chatserver.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import edu.stevens.cs522.chatserver.contracts.MessageContract;
import edu.stevens.cs522.chatserver.contracts.PeerContract;
import edu.stevens.cs522.chatserver.entities.Message;
import edu.stevens.cs522.chatserver.entities.Peer;

/**
 * Created by dduggan.
 */

public class ChatDbAdapter {

    private static final String DATABASE_NAME = "messages.db";

    private static final String MESSAGE_TABLE = "messages";

    private static final String PEER_TABLE = "peers";

    private static final int DATABASE_VERSION = 1;

    private DatabaseHelper dbHelper;

    private SQLiteDatabase db;

    private static final String PEER_FK = "peer_fk";

    private static final String MESSAGES_PEER_INDEX = "MessagesPeerIndex";

    private static final String PEER_NAME_INDEX = "PeerNameIndex";

    private static final String _ID = "_id";



    public static class DatabaseHelper extends SQLiteOpenHelper {


//        private static final String DATABASE_CREATE = null;
        private static final String CREATE_PEER_TABLE =
            "create table " + PEER_TABLE + "("
                    + PeerContract._ID + " integer primary key, "
                    + PeerContract.NAME + " text not null, "
                    + PeerContract.TIMESTAMP + " integer, "
                    + PeerContract.LATITUDE + " real, "
                    + PeerContract.LONGITUDE + " real, "
                    + PeerContract.ADDRESS + " text not null, "
                    + PeerContract.PORT + " integer not null"
            + ");";

        private static final String CREATE_MESSAGE_TABLE =
            "create table " + MESSAGE_TABLE + "("
                    + MessageContract._ID + " integer primary key, "
                    + MessageContract.CHAT_ROOM + " text not null, "
                    + MessageContract.MESSAGE_TEXT + " text not null, "
                    + MessageContract.TIMESTAMP + " integer, "
                    + MessageContract.LATITUDE + " real, "
                    + MessageContract.LONGITUDE + " real, "
                    + MessageContract.SENDER + " text not null, "
                    + MessageContract.SENDER_ID + " integer not null, "
                    + PEER_FK + " integer not null, "
                    + "FOREIGN KEY (" + PEER_FK + ") REFERENCES " + PEER_TABLE + "(" + _ID + ") ON DELETE CASCADE"
            + ");";

        private static final String MESSAGES_P_INDEX_CREATE = "CREATE INDEX "
                + MESSAGES_PEER_INDEX + " ON " + MESSAGE_TABLE + "(" + PEER_FK + ");";

        private static final String PEER_NAME_INDEX_CREATE = "CREATE INDEX "
                + PEER_NAME_INDEX + " ON " + PEER_TABLE + "(" + PeerContract.NAME + ");";
//        TODO


        public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // TODO
            db.execSQL(CREATE_PEER_TABLE);
            db.execSQL(CREATE_MESSAGE_TABLE);
            db.execSQL(PEER_NAME_INDEX_CREATE);
            db.execSQL(MESSAGES_P_INDEX_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO
            db.execSQL("PRAGMA foreign_keys=ON;");
            db.execSQL("drop table if exists " + PEER_TABLE);
            db.execSQL("drop table if exists " + MESSAGE_TABLE);
            onCreate(db);
        }
    }


    public ChatDbAdapter(Context _context) {
        dbHelper = new DatabaseHelper(_context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void open() throws SQLException {
        // TODO
        db = dbHelper.getWritableDatabase();
        db.execSQL("PRAGMA foreign_keys=ON;");
    }

    public Cursor fetchAllMessages() {
        // TODO
        //return null;
        db.execSQL("PRAGMA foreign_keys=ON;");
        return db.query(MESSAGE_TABLE,null,null,null,null,null,null);
    }

    public Cursor fetchAllPeers() {
        // TODO
        //return null;
        db.execSQL("PRAGMA foreign_keys=ON;");
        return db.query(PEER_TABLE,null,null,null,null,null,null);
    }

    public Peer fetchPeer(long peerId) {
        // TODO
        // return null;
        String selection = (PeerContract._ID + "=?");
        String[] selectionArgs = new String[] { Long.toString(peerId)};
        db.execSQL("PRAGMA foreign_keys=ON;");
        Cursor cursor = db.query(PEER_TABLE, null, selection, selectionArgs, null, null, null);
        if(cursor.moveToFirst()){
            Peer peer = new Peer(cursor);
            return peer;
        } else{
            return null;
        }
    }

    public Cursor fetchMessagesFromPeer(Peer peer) {
        // TODO
        //return null;
        String selection = (MessageContract.SENDER_ID + "=?");
        String[] selectionArgs = new String[] {Long.toString(peer.id)};
        db.execSQL("PRAGMA foreign_keys=ON;");
        return db.query(MESSAGE_TABLE,null, selection, selectionArgs, null,null,null);

    }

    public long persist(Message message) throws SQLException {
        // TODO
        //throw new IllegalStateException("Unimplemented: persist message");
        ContentValues out = new ContentValues();
        message.writeToProvider(out);
        out.put(PEER_FK,message.senderId);
        return db.insert(MESSAGE_TABLE,null,out);
    }

    /**
     * Add a peer record if it does not already exist; update information if it is already defined.
     */
    public long persist(Peer peer) throws SQLException {
        // TODO
        // throw new IllegalStateException("Unimplemented: persist peer")
        ContentValues out = new ContentValues();
        peer.writeToProvider(out);
        String selection = PeerContract.NAME+ "=?";
        String[] selectionArgs = new String[] { peer.name };
        db.execSQL("PRAGMA foreign_keys=ON;");
        Cursor cursor = db.query(PEER_TABLE, null, selection, selectionArgs, null, null, null);
        if (cursor.moveToFirst()){
            db.update(PEER_TABLE,out, selection, selectionArgs);
            return PeerContract.getId(cursor);
        } else{

            return db.insert(PEER_TABLE, null, out);

        }
    }

    public void close() {
        // TODO
        db.close();
        db = null;
    }
}