package edu.stevens.cs522.chat.databases;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import java.util.List;

import edu.stevens.cs522.chat.entities.Message;
import edu.stevens.cs522.chat.entities.Peer;

// TODO add annotations for Repository pattern
@Dao
public abstract class MessageDAO {

    // TODO
    @Query("SELECT * FROM message")
    public abstract LiveData<List<Message>> fetchAllMessages();

    // TODO
    @Query("SELECT * FROM message WHERE senderId = :peerId")
    public abstract LiveData<List<Message>> fetchMessagesFromPeer(long peerId);

    // TODO
    @Insert
    protected abstract void insert(Message message);

    // TODO
    @Update
    protected abstract void update(Message message);

    /**
     * Insert other peer's messages and update our own, with input from server.
     */
    public void upsert(long senderId, Message message) {
        if (senderId == message.senderId) {
            // One of our own messages returned from the server, update sequenceId
            update(message);
        } else {
            // Another peer's message, with sequenceId set by server
            // message.id = 0;
            insert(message);
        }
    }

}
