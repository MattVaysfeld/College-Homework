const Data = require('./userApi');
const showData = Data;
module.exports = {
  show: showData
};